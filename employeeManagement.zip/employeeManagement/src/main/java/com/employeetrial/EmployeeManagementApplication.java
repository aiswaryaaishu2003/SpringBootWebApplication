package com.employeetrial;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

import com.employeetrial.entity.Employee;
import com.employeetrial.service.EmployeeService;

@SpringBootApplication
public class EmployeeManagementApplication {


	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementApplication.class, args);
	}
	@Autowired
	private EmployeeService employeeService;
		@Bean
		public CommandLineRunner initDB()
		{
			return (args) -> {
				this.employeeService.save(new Employee("john","2389898","ernakulam"));
				this.employeeService.save(new Employee("jeo","2409988888","Thrissur"));
			};
	}
	
}
