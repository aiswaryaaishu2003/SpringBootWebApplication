package com.employeetrial.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;

//import org.springframework.data.annotation.Id;
import javax.persistence.Id;

import org.springframework.http.HttpStatus;
@Entity
public class Employee {
     
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	//@Column(name="employeeId")
	private Long id;
	//@Column(name="employee name")
	private String name;
	//@Column(name="employee number")
	private String number;
	
	private String location;
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public Employee() {
		super();
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getNumber() {
		return number;
	}
	public void setNumber(String number) {
		this.number = number;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public Employee(String name, String number, String location) {
		super();
		this.name = name;
		this.number = number;
		this.location = location;
	}

	
	
	
	
}
