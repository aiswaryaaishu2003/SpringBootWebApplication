package com.employeetrial.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.employeetrial.entity.Employee;

import com.employeetrial.repository.EmployeeRepository;
@Service
public class EmployeeServiceImpl implements EmployeeService{
	
	@Autowired
  private EmployeeRepository employeeRepository;


@Override
public Employee save(Employee employee) {
	
	return employeeRepository.save(employee);
}
@Override
public List<Employee> getAllEmployee() {
	
	return employeeRepository.findAll();
}

@Override
public Employee getEmployeeById(Long id) {
	Optional<Employee> employee = employeeRepository.findById(id);
	return employeeRepository.findById(id).orElseThrow();
	}


@Override
public Employee update(Employee employee, Long id) {
	
	return employeeRepository.save(employee);
}

@Override
public void delete(Long id) {
	employeeRepository.deleteById(id);
}




}











