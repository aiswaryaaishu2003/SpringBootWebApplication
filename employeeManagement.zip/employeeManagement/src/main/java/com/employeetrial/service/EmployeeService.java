package com.employeetrial.service;

import java.util.List;
import java.util.Optional;

import com.employeetrial.entity.Employee;

public interface EmployeeService {
	Employee save(Employee employee);
	
	 List<Employee>getAllEmployee();
	 
	 Employee getEmployeeById(Long id);
	 
	 Employee update(Employee employee,Long id); 
	 
	 void delete(Long id);

//	Employee findById(Long id);

	
	
}
	 
	 

	 
